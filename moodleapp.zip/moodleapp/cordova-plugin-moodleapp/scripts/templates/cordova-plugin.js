cordova.define("[[PLUGIN_NAME]]", function(require, exports, module) {
    [[PLUGIN_CONTENTS]]
});
